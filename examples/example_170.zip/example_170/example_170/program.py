import math
from pulseapi import RobotPulse, pose, position, MT_LINEAR

SPEED = 30
VELOCITY = 40
ACCELERATION = 50
TCP_VELOCITY_1CM = 0.01

home_pose = pose([0, -90, 0, -90, -90, 0])
start_pose = pose([0, -90, 90, -90, -90, 0])
pose_targets = [
    pose([10, -90, 90, -90, -90, 0]),
    pose([10, -90, 0, -90, -90, 0]),
]
position_target = position([-0.42, -0.12, 0.35], [math.pi, 0, 0])
position_targets = [
    position([-0.37, -0.12, 0.35], [math.pi, 0, 0]),
    position([-0.42, -0.12, 0.35], [math.pi, 0, 0]),
    position([-0.42, -0.17, 0.35], [math.pi, 0, 0]),
    position([-0.37, -0.17, 0.35], [math.pi, 0, 0]),
]


def example_before_all(robot):
    robot.set_pose(home_pose, speed=SPEED)
    robot.await_stop()


def example_before_each(robot):
    robot.set_pose(start_pose, velocity=VELOCITY, acceleration=ACCELERATION)
    robot.await_stop()


def example_execute(robot):
    robot.set_position(
        position_target, velocity=VELOCITY, acceleration=ACCELERATION
    )
    robot.await_stop()
    
    robot.run_positions(position_targets, SPEED)
    robot.await_stop()
    
    robot.run_positions(
        position_targets,
        velocity=VELOCITY,
        acceleration=ACCELERATION,
        motion_type=MT_LINEAR,
    )
    robot.await_stop()


def example_after_each(robot):
    robot.run_positions(
        position_targets[::-1],
        tcp_max_velocity=TCP_VELOCITY_1CM,
        motion_type=MT_LINEAR,
    )
    robot.await_stop(0.5)


def example_after_all(robot):
    robot.set_pose(home_pose, speed=SPEED)
    robot.await_stop()


class Instance:
    def __init__(self, robot_ip: str, *args, **kwargs):
        self._robot_ip = robot_ip
    
    def __enter__(self):
        self.robot = RobotPulse(self._robot_ip)
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        if exc_value is not None and exc_type != SystemExit:
            self.on_error(exc_value)
    
    def before_all(self):
        example_before_all(self.robot)

    def before_each(self):
        example_before_each(self.robot)

    def execute(self):
        example_execute(self.robot)

    def after_each(self):
        example_after_each(self.robot)

    def after_all(self):
        # do not use stdout in this block in the program
        # that is uploaded to the robot
        example_after_all(self.robot)

    def on_error(self, exc_value):
        self.robot.freeze()
